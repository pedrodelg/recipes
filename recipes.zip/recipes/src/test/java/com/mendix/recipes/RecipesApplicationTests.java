package com.mendix.recipes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecipesApplicationTests {

	@Test
	void contextLoads() {
	}

}
